# Lorem Ipsum

Lorem Ipsum plugin for Acode editor. To use this plugin, search `Lorem ipsum` in command pallete. Thank you for installing this plugin.
