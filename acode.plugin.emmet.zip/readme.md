## Emmet

As you might know acode already has emmet support, But it only supports on html,css(other css preprocessors) extension . But sometimes you will need emmet html or css emmet in `jsx/tsx`, `svelte`, `markdown` etc . **So this plugin adds support for html/css Emmet in all extensions**


### USE

- `Ctrl - h` will trigger html emmet
- `Ctrl - e` will trigger css emmet
- `Ctrl - j` This is for jsx . This will trigger html emmet but class will be replaced with className


### Issues

- Report issues on my telegram [Legend Sabbir](https://t.me/legendSabbir)