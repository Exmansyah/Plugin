# Path Autocomplete

<div class="video-container">
  <video src="https://cdn.jsdelivr.net/gh/paidPlugins/cdn@latest/path-autocomplete-demo.mp4" autoplay muted loop style="width: 100%;height: auto;object-fit: cover;"></video>
</div>

- Get path suggestions efficiently 🔥
- Has a cache system .
- Performance is the main focus
- Only triggers inside string Token
- If you create or Add new file refresh path using command pallette . type `Reset Path Cache`
- [Source Code -- Not Updated --](https://gist.github.com/legendSabbir/eba2e344e21c6cbe39223a277250c557)
