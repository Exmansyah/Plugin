# Acode Pinch to Zoom Plugin

![Pinch2Zoom](https://i.postimg.cc/MGpv3rGM/IMG-20240127-220023.jpg)

## Features

- **Pinch to Zoom:** Easily zoom in and out of the Acode editor content using the pinch gesture on supported devices.

## Installation

1. Open Acode editor.
2. Navigate to the Plugins section.
3. Search for "Pinch to Zoom" in the plugin repository.
4. Install the plugin.

## Usage

Once the plugin is installed, the pinch-to-zoom functionality is automatically enabled. Perform a pinch gesture on the editor content to zoom in or out.

## Support

For any issues, feedback, or suggestions, feel free to reach out:

- **Email:** sourav0chand@gmail.com

- **Telegram:** https://t.me/sourav0chand

## License

This Acode Pinch to Zoom plugin is licensed under the [MIT License](LICENSE).
