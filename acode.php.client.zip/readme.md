# Acode PHP Language Client

> Acode Language Cliemt plugin is required to use this plugin.

This plugin adds extended support for php in Acode

> **WARNING** Acode Language Client v1.0.3 or higher is required for this plugin
to work properly.

___
## Supported Features

- Auto Completion
- Import Completion
- Code Formatting (Full / Selected Text)
- Go to definition, declaration, implementation, references
- Rename Symbol
- Code actions
- Error Diagnostics

___
## Setup

This plugin uses `phpactor` for the Language Server

if already installed set the installation path in the `serverPath` config.

To check if installed run:
```bash
phpactor --version
```


To install run the following

```bash
curl -Lo phpactor.phar https://github.com/phpactor/phpactor/releases/latest/download/phpactor.phar && chmod a+x phpactor.phar && mv phpactor.phar ~/../usr/bin/phpactor
```
