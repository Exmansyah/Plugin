# Volumn Cursor

Control editor cursor.

## Updates

### 0.0.1

- Added settings to change direction of cursor movement.
