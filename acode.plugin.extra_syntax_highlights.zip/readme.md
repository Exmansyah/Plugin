# Extra Syntax Highlights

* After installing Restart The App
* Report issues on my telegram 
* My telegram [Legend Sabbir](https://t.me/legendSabbir)

<br>
<img src="https://i.ibb.co/J2dmJYQ/Screenshot-20230830-144040.jpg" alt="Bracket Pair" width="720" height="346" style="width: 100%;height: auto;display: block;">
<br>
<img src="https://i.ibb.co/FKkvTBf/Screenshot-20230830-143412.jpg" alt="Css Colorizer" width="720" height="234" style="width: 100%;height: auto;display: block;">
<br>

### Modify colors in plugin settings page

### Astro
- Syntax highlighting for Astro 

### Svelte
- Syntax highlighting for Svelte
- lang="ts" will Highlight TypeScript
- lang="less" will Highlight less
- lang="scss" will Highlight scss


### Bracket Pair colorizer
Only the mode listed bellow has bracket pair colorizer
- Javascript
- Less
- Scss
- TypeScript


### Rainbow Indent Guide
Colorize your indent lines . Works in all modes and all themes


### Color Preview
Available Modes
- Css
- Less
- Scss

### Cursor colorizer
Cursor color will change based on current position
You can disable this from settings



## This plugin add some extra syntax highlighting rules for the languages listed bellow

- Html
- Css
- Javascript
- TypeScript
- Scss
- Less
- Svelte

--> If you face any issues just uninstall this plugin and Restart the App