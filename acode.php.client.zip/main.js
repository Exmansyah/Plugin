(function () {
  let plugin = {
    id: "acode.php.client"
  };

  let url = acode.require("url");

  class PhpPlugin {
    init() {
      let acodeLanguageClient = acode.require("acode-language-client");
      if (acodeLanguageClient) {
        this.setupLangaugeClient(acodeLanguageClient);
      } else {
        window.addEventListener("plugin.install", ({ detail }) => {
          if (detail.name === "acode-language-client") {
            acodeLanguageClient = acode.require("acode-language-client");
            this.setupLangaugeClient(acodeLanguageClient);
          }
        });
      }
    }

    setupLangaugeClient(acodeLanguageClient) {
      let socket = acodeLanguageClient.getSocketForCommand(
        this.settings.serverPath, ["language-server"]
      );

      let phpClient = new acodeLanguageClient.LanguageClient({
        type: "socket", socket
      });
      acodeLanguageClient.registerService("php", phpClient);
    }

    destroy() {}
    
    get settings() {
      if (!window.acode) {
        return this.defaultSettings;
      }

      const AppSettings = acode.require("settings");
      let value = AppSettings.value[plugin.id];
      if (!value) {
        value = AppSettings.value[plugin.id] = this.defaultSettings;
        AppSettings.update();
      }
      return value;
    }

    get defaultSettings() {
      return {
        serverPath: "/data/data/com.termux/files/usr/bin/phpactor"
      };
    }

    get settingsObject() {
      const AppSettings = acode.require("settings");
      return {
        list: [
          {
            key: "serverPath",
            text: "Path to phpactor server",
            prompt: "Path to phpactor server",
            promptType: "text",
            value: this.settings.serverPath
          }
        ],
        cb: (key, value) => {
          switch (key) {
            case "serverPath":
              if (!value.endsWith("")) {
                value = value + "/";
              }
              break;
          }
          AppSettings.value[plugin.id][key] = value;
          AppSettings.update();
        }
      };
    }
  }

  if (window.acode) {
    const php = new PhpPlugin();
    acode.setPluginInit(
      plugin.id,
      (baseUrl, $page, { cacheFileUrl, cacheFile }) => {
        if (!baseUrl.endsWith("/")) baseUrl += "/";
        php.baseUrl = baseUrl;
        php.init($page, cacheFile, cacheFileUrl);
      },
      php.settingsObject
    );
    acode.setPluginUnmount(plugin.id, () => {
      php.destroy();
    });
  }
})();
