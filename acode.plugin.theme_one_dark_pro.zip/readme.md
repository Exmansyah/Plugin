# One Dark Pro

Go to `Settings` -> `Theme` -> `Editor Theme` -> scroll To bottom and select `One Dark Pro`
<br>

<img src="https://i.ibb.co/Xy7ymRy/Screenshot-20230830-153900.jpg" alt="JavaScript image" border="0" height="395" width="720" style="width: 100%;height: auto;display: block;">
<br>

<img src="https://i.ibb.co/WBc9ShQ/Screenshot-20230830-153941.jpg" alt="Html Image" border="0" height="380" width="720" style="width: 100%;height: auto;display: block;">
<br>

<img src="https://i.ibb.co/J7rc661/Screenshot-20230830-153921.jpg" alt="Css Image" border="0" height="229" width="720" style="width: 100%;height: auto;display: block;">
<br>

## Want to create editor theme for acode ?
[Go to This repository](https://github.com/legendSabbir/acode-editorTheme-template.git)