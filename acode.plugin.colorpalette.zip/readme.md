# Color Palette Generator

This Plugin is specially for Frontend Developers , it helps to generate color palette for your website design from a image of your favourite UI.

Note:- Generated colour may be slightly different from actual color and it may be possible that all Color in image are not listed in generated color palette

# Latest Version 
`1.0.6` 

• Bug fixes


# Usage

• Type "Color Palette" in command pallete("..." icon in bottom toolbar) select a image from which you want to extract color and wait for response.

• For saving pallete , click on save button , file browser will open select folder where you want to save


Still having trouble in usage ? [Click here](https://github.com/mayank0274/acode-color-palette-generator-plugin/blob/main/usage-guide.gif)


# 📬 Features request / Bug report

Create a issue in Github repo

# Github repo link

[Click here to visit this plugin GitHub repo](https://github.com/mayank0274/acode-color-palette-generator-plugin)